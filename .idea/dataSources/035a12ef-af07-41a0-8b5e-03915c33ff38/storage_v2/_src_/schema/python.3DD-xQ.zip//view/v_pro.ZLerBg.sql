create view v_pro as
select `are`.`title` AS `pro_title`, `book`.`title` AS `title`
from (`python`.`areas` `are`
         join `python`.`areas` `book` on ((`book`.`pid` = `are`.`id`)));

